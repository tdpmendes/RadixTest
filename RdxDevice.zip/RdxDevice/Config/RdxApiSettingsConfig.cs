﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RdxDevice.Config
{
    public class RdxApiSettingsConfig
    {
        public string ApiBaseUrl { get; set; }
        public string ApiRoute { get; set; }
    }
}
